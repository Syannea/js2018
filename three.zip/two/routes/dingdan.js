'use strict';
var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
var user = require('../model/dingdan');


/* GET home page. */
router.post('/', function(req, res) {
	var people_name = req.body.people_name;
	console.log(people_name);
	var phone = req.body.phone;
	console.log(phone);
	var data = req.body.data;
	console.log(data);
	var people = req.body.people;
	console.log(people);
	dingdan.create({
		people_name: people_name,
		phone: phone,
		data: data,
		people: people
	});
	
});


module.exports = router;