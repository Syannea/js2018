var mongoose = require('mongoose');

var UserSchema = new mongoose.Schema({
    people_name: String,
    phone: String,
    data: String,
    people: String
});
module.exports = mongoose.model('dingdan', UserSchema,'dingdan');