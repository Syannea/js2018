var mongoose = require('mongoose');

var UserSchema = new mongoose.Schema({
    menu_name: String,
    tupian: String,
    neirong: String
});
module.exports = mongoose.model('menu', UserSchema,'menu');